public class Acuatico{
	boolean remos;
}