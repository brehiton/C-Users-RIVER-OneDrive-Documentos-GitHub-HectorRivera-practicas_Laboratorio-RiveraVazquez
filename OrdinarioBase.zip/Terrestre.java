public class Terrestre{
	int llantas;
}