public class Vehiculo {
	String marca;
	int modelo;
	float costo;

}